---
name: pharma-daily-briefing
description: 医药行业每日情报自动生成技能。当用户要求"写医药日报"、"医药情报"、"医药行业今日动态"、"搜索医药行业最新消息"、"生成医药报告"、"每日医药要闻"、"医药行业每日简报"等时触发。自动执行多路并行联网搜索，整合信息生成结构化日报，包含事件概览、深度分析和选题建议，完成后自动推送至微信。支持自定义时间窗口（默认48小时）和搜索关键词。
---

# 医药每日情报 · Skill 工作流

## ⚡ 快速启动

用户说"写一份医药日报" → 立即进入 Step 1，无需多问。

## Step 1 · 确定搜索范围（30秒）

与用户确认以下内容（可接受模糊指令）：

| 选项 | 说明 | 适用场景 |
|------|------|---------|
| 时间窗口 | 默认**48小时**，可调整为24h/72h/一周 | 用户明确指定时 |
| 重点领域 | 默认8路全覆盖，可指定只看GLP-1/ADC等 | 用户说明关注方向时 |
| 报告深度 | 简报（事件罗列）vs 深度报告（10事件+2深度+3选题） | 默认深度 |

**若用户只说"搜一下今天医药新闻"** → 默认执行全部8路搜索 + 深度报告格式。

## Step 2 · 执行多路搜索

在 `{workspace}/search/` 下运行：

```bash
node "C:\Users\qf-hqu\.qclaw\skills\pharma-daily-briefing\scripts\prosearch_runner.js" "{workspace}/search"
```

8路搜索并行执行，结果写入 `result_s01.json` ~ `result_s08.json`。

**运行前确认**：确保 Auth Gateway / Agent World 代理服务已启动。

**如果 runner 失败**（Auth Gateway 问题），降级为手动搜索：
- 使用 online-search skill，逐路手动搜索
- 关键词参考 `references/search-strategy.md`

**如果 runner 再次失败**（PowerShell 转义问题）：
- 直接用 `node prosearch.cjs '{"keyword":"..."}'` 逐条执行
- 问题根因：PowerShell 对 JSON 字符串中引号的转义处理有 bug
- 临时方案：修改 prosearch.cjs 接受 stdin 输入（不推荐，持久修改 skill 文件）

## Step 3 · 读取与解析结果

读取所有 `result_s*.json`，优先读取高信号文档（前3条结果）。

JSON 解析提示：
- `result.data.docs[n].passage` = 正文摘要
- `result.data.docs[n].title` = 文章标题
- `result.data.docs[n].date` = 发布时间
- `result.data.docs[n].url` = 原始链接
- `result.data.docs[n].score` = 相关度（0-1，越高越相关）

**数据质量问题处理**：
- 部分中文字段可能出现 UTF-8 mojibake（显示为乱码）→ 忽略该字段，用英文 passage 字段代替
- passage 为空 → 跳过该条，参考同文档的 title
- docs 数量不足 → 使用 web_fetch 抓取原网页补充

## Step 4 · 生成报告

按 `references/report-format.md` 的格式规范输出报告。

**输出位置**：直接输出到对话，不保存文件（除非用户明确要求）。

**结构**：
```
# 🧪 医药行业每日情报 · YYYY年M月D日
[头部元数据]

## 一、[N]大事件概览
（按热度排序：🔥 > 📈 > ➡️）

## 二、[M]个关键事件深度分析
（选当日最重要/最具争议的2-3个事件）

## 三、Top 3 选题建议
（从媒体/内容创作角度的报道建议）
```

**报告质量检查**：
- [ ] 至少10个具体数字（金额、百分比、时间节点）
- [ ] 至少3条不同来源的观点
- [ ] 每条事件有热度标记（🔥/📈/➡️）
- [ ] 有争议点或多元视角
- [ ] 末尾有报告时间和免责声明

## Step 5 · 推送微信（自动执行）

**必须执行**：报告生成后，立即使用 `message` 工具推送到微信。

```javascript
message({
  action: "send",
  channel: "openclaw-weixin",
  message: "完整报告文本"
})
```

**分段发送规则**（微信单条消息有长度限制，约2000字）：
- 报告全文 < 1800 字 → 一次发送
- 报告全文较长 → 拆分为 2-3 条，每条标注序号 [1/N] [2/N] ...
- 拆分位置：优先在"## 二、深度分析"和"## 三、选题建议"之间分段
- 示例：
  ```
  [1/2] 🧪 医药日报 · 4月10日
  
  一、十大事件概览
  [内容...]
  
  ───
  [2/2]
  
  二、深度分析
  [内容...]
  
  三、Top 3 选题建议
  [内容...]
  
  ⚠️ 本报告仅供选题参考，不构成投资建议
  ```

**图片/附件**：无需附加，文字报告即可。

## Step 6 · 交付与迭代

将报告在对话中输出，并等待反馈：

- **用户要求修改**：调整深度/侧重点，重新输出相关章节并重新推送
- **用户要求补充**：针对特定事件 web_fetch 深挖
- **用户要求保存**：输出报告写入 `{workspace}/reports/pharma-YYYY-MM-DD.md`

## 参考文件

- `references/search-strategy.md` — 8路搜索配置、关键词设计、错误处理
- `references/report-format.md` — 报告写作格式规范、标签体系、质量标准
- `scripts/prosearch_runner.js` — 多路搜索自动化脚本（需 Auth Gateway）

## 技术注意事项

### prosearch_runner.js 常见错误

| 症状 | 原因 | 解决 |
|------|------|------|
| `Command failed` | Auth Gateway 未启动 | `openclaw gateway start` 或确认 QClaw 代理运行中 |
| `JSON 参数解析失败` | PowerShell 引号转义 | 使用 runner 脚本（内部通过 Node.js exec 传递参数） |
| 所有搜索都返回 0 条 | 时间戳计算错误或网络问题 | 检查 from_time / to_time 是否合理 |

### 关于 Auth Gateway

prosearch_runner.js 依赖本地 Auth Gateway（默认端口 19000）作为代理。
Auth Gateway 通常由 QClaw 客户端或 Agent World 运行时自动启动。

若遇到认证问题，参考：
- `H:\Qclaw\resources\openclaw\config\skills\online-search\SKILL.md`
- `H:\Qclaw\resources\openclaw\node_modules\openclaw\skills\healthcheck\SKILL.md`
