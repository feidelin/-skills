/**
 * prosearch_runner.js — 多路并行医药情报搜索脚本
 *
 * 用途：并行执行多条 prosearch 搜索，结果写入 result_s{N}.json
 *
 * 用法：
 *   node prosearch_runner.js <workspace_dir>
 *
 * 修复：使用 spawnSync + argv 数组传参，彻底绕开 Windows PowerShell/CMD 的引号转义问题
 */

const {spawnSync} = require('child_process');
const fs = require('fs');
const path = require('path');

const SCRIPT = 'C:\\Program Files\\QClaw\\resources\\openclaw\\config\\skills\\online-search\\scripts\\prosearch.cjs';
const NODE = process.execPath;
const WORKSPACE = process.argv[2] || process.cwd();

function buildSearchConfigs(nowSeconds) {
  const twoDaysAgo = nowSeconds - 172800;
  const searches = [
    {keyword:'医药行业最新动态 2026年4月',from_time:twoDaysAgo,to_time:nowSeconds},
    {keyword:'GLP-1 创新药 最新进展 2026年4月',from_time:twoDaysAgo,to_time:nowSeconds},
    {keyword:'ADC抗体偶联药 最新临床 2026年4月',from_time:twoDaysAgo,to_time:nowSeconds},
    {keyword:'医疗器械 集采 最新动态 2026年4月',from_time:twoDaysAgo,to_time:nowSeconds},
    {keyword:'AI制药 医疗大模型 最新动态 2026年4月',from_time:twoDaysAgo,to_time:nowSeconds},
    {keyword:'国家药监局 FDA 新药获批 2026年4月',from_time:twoDaysAgo,to_time:nowSeconds},
    {keyword:'百济神州 恒瑞医药 药明康德 2026年4月 最新动态',from_time:twoDaysAgo,to_time:nowSeconds},
    {keyword:'AACR ASCO 2026 国产创新药 临床数据',from_time:twoDaysAgo,to_time:nowSeconds}
  ];
  try {
    const extra = process.env.SEARCH_EXTRA;
    if (extra) {
      JSON.parse(extra).forEach(item => searches.push({keyword:item.keyword,from_time:twoDaysAgo,to_time:nowSeconds}));
    }
  } catch(e) {}
  return searches;
}

function runSearch(params, outputPath) {
  const jsonArg = JSON.stringify(params);
  const result = spawnSync(NODE, [SCRIPT, jsonArg], {encoding:'utf8', timeout:30000});
  const out = result.stdout || '';
  if (result.status === 0 && out.trim()) {
    fs.writeFileSync(outputPath, out, 'utf8');
    try {
      const p = JSON.parse(out.trim());
      return {success:true, count: p.data ? p.data.totalResults : 0};
    } catch(e) { return {success:true, count:0}; }
  } else {
    const errMsg = (result.stderr||'unknown error').slice(0,200);
    fs.writeFileSync(outputPath, JSON.stringify({success:false, error:errMsg}), 'utf8');
    return {success:false, count:0, message:errMsg};
  }
}

function main() {
  const nowSeconds = Math.floor(Date.now() / 1000);
  const configs = buildSearchConfigs(nowSeconds);
  console.log(`[prosearch_runner] 开始 ${configs.length} 路搜索，时间窗口: ${nowSeconds - 172800} ~ ${nowSeconds}`);
  console.log(`[prosearch_runner] 工作目录: ${WORKSPACE}`);
  for (let i = 0; i < configs.length; i++) {
    const cfg = configs[i];
    const seq = String(i + 1).padStart(2, '0');
    const outFile = path.join(WORKSPACE, `result_s${seq}.json`);
    process.stdout.write(`[${seq}/${configs.length}] ${cfg.keyword.slice(0, 30)}... `);
    const r = runSearch(cfg, outFile);
    console.log(`${r.success ? '✅' : '❌'} ${r.count} 条`);
  }
  console.log('[prosearch_runner] 全部完成。');
}

main();
