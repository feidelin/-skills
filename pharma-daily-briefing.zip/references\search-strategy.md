# 医药情报多路搜索策略

## 默认8路搜索配置

时间窗口：最近48小时（自动计算 from_time / to_time）

| # | 搜索路 | 关键词 | 覆盖主题 |
|---|--------|--------|---------|
| s1 | 全行业动态 | 医药行业最新动态 2026年4月 | 政策、监管、市场行情 |
| s2 | GLP-1/减重药 | GLP-1 创新药 最新进展 2026年4月 | 礼来、诺和诺德、国内GLP-1玩家 |
| s3 | ADC/双抗 | ADC抗体偶联药 最新临床 2026年4月 | 临床数据、靶点、BD交易 |
| s4 | 器械/集采 | 医疗器械 集采 最新动态 2026年4月 | 集采、价格、国产替代 |
| s5 | AI制药/大模型 | AI制药 医疗大模型 最新动态 2026年4月 | AI+医疗、大模型、数字化 |
| s6 | 监管/新药获批 | 国家药监局 FDA 新药获批 2026年4月 | NMPA/FDA批准、快速通道 |
| s7 | 头部公司 | 百济神州 恒瑞医药 药明康德 2026年4月 最新动态 | 龙头公司公告、业绩、股价 |
| s8 | 学术会议 | AACR ASCO 2026 国产创新药 临床数据 | 学术会议、临床数据催化剂 |

## 自定义搜索

可通过环境变量 `SEARCH_EXTRA` 追加额外搜索（JSON 数组格式）：

```json
[
  {"keyword": "核药 最新进展 2026年4月"},
  {"keyword": "合成生物学 医药 最新动态 2026年4月"},
  {"keyword": "mRNA疫苗 最新进展 2026年4月"}
]
```

## 时间戳计算说明

- `nowSeconds` = `Math.floor(Date.now() / 1000)`（当前 UTC+8 时间戳）
- `from_time` = `nowSeconds - 172800`（往前48小时）
- `to_time` = `nowSeconds`（截至当前）

若需调整时间窗口，修改 `prosearch_runner.js` 中 `twoDaysAgo` 的计算值（秒数）。

## 搜索优先级建议

**必选（基础覆盖）**：s1 + s6（总览+监管获批）
**核心主题（按需选）**：s2（GLP-1）、s3（ADC）、s7（头部公司）
**加分项（深度洞察）**：s5（AI制药）、s8（AACR/ASCO）

## 输出文件命名

```
search_s01.json   ← 输入参数
result_s01.json   ← 搜索结果 JSON
search_s02.json
result_s02.json
...（以此类推）
```

result_s*.json 结构：
```json
{
  "success": true,
  "message": "摘要文本（用于快速浏览）",
  "data": {
    "query": "原始关键词",
    "totalResults": 10,
    "docs": [ ... ]  // 原始文档列表
  }
}
```

## 常见错误处理

| 错误信息 | 原因 | 解决 |
|---------|------|------|
| `Command failed` | Auth Gateway 未启动 | 启动 QClaw/Agent World |
| `JSON 参数解析失败` | JSON 格式错误或 PowerShell 转义问题 | 使用 runner 脚本内部传递 |
| `timeout` | 网络慢或代理问题 | 增大 timeout 参数 |
| `results count = 0` | 关键词无匹配 | 调整关键词或扩大时间窗口 |
